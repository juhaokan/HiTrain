// +build no-run OMIT

package main

func main() {
	for {
	}
}
